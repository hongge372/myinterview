### 5.2.7 `RTCDtxStatus` 枚举

```java

```

```
enum RTCDtxStatus {
         "disabled",
         "enabled"
         };
```

| RTCDtxStatus枚举描述 |                                  |
| -------------------- | -------------------------------- |
| `disabled`           | 不连续传输被禁用。               |
| `enabled`            | 如果协商成功，不连续传输被启用。 |



