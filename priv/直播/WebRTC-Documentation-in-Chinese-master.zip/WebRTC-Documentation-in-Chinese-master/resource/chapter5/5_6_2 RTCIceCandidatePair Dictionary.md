### 5.6.2 `RTCIceCandidatePair`字典

```java
dictionary RTCIceCandidatePair {
             RTCIceCandidate local;
             RTCIceCandidate remote;
};
```

**字典`RTCIceCandidatePair`成员**

`RTCIceCandidate`类型的`local`：本地ICE 候选者。

`RTCIceCandidate`类型的`remote`：远程ICE 候选者。
