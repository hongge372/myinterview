### 5.6.1 `RTCIceParameters`字典

```java
dictionary RTCIceParameters {
             DOMString usernameFragment;
             DOMString password;
};
```

**字典`RTCIceParameters`成员**

`DOMString`类型的`usernameFragment`:在[ICE],章节7.1.2.3中定义的ICE用户名片段。

`DOMString`类型的`password`:在[ICE],章节7.1.2.3中定义的ICE密码。


