### 5.2.14 `RTCRtpHeaderExtensionCapability`字典

```java
dictionary RTCRtpHeaderExtensionCapability {
             DOMString uri;
};
```

**字典`RTCRtpHeaderExtensionCapability`成员**

**DOMString类型**的`uri`:

[RFC5285]中定义的RTP标头扩展的URI。

