### 5.2.5 `RTCRtpDecodingParameters`字典

```java
dictionary RTCRtpDecodingParameters : RTCRtpCodingParameters {
};
```

