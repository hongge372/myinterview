## [4.4 RTCPeerConnection 接口](http://w3c.github.io/webrtc-pc/#rtcpeerconnection-interface)

[[JSEP](http://w3c.github.io/webrtc-pc/#bib-JSEP)]规范作为一个整体，描述了[`RTCPeerConnection`](http://w3c.github.io/webrtc-pc/#dom-rtcpeerconnection)如何运行的细节。适当时提供对[[JSEP](http://w3c.github.io/webrtc-pc/#bib-JSEP)]特定小节的参考。
