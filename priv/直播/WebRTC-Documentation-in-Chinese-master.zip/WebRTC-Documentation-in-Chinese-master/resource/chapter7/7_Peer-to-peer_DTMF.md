# 7 点对点DTMF

本节介绍`RTCRtpSender`上的一个接口，用于在`RTCPeerConnection`上发送DTMF（电话键盘）值。有关如何将DTMF发送到其他对等方的详细信息，请参见[RTCWEB-AUDIO]。

