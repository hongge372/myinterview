## 11.3 `RTCErrorEventInit` 字典

```java
dictionary RTCErrorEventInit : EventInit {
     required RTCError error;
};
```

### 11.3.1 字典RTCErrorEventInit成员

`RTCError`类型的`error`,默认为`null`:

描述与事件(如果存在)关联的错误的`RTCError`。



