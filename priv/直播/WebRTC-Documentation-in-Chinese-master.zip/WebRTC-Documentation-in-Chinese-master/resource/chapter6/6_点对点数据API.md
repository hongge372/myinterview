# 6 对等数据API

对等数据API允许网络应用点对点发送接收通用应用数据。发送接收数据的API模拟`WebSockets`[WEBSOCKETS-API]的行为。

