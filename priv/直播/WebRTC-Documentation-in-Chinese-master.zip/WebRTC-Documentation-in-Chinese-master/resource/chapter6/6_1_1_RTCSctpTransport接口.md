### 6.1.1 `RTCSctpTransport`接口



`RTCSctpTransport`接口允许应用获取SCTP绑定到特定SCTP关联的数据通道的信息。
